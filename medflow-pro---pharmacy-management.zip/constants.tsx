
import React from 'react';
import { 
  LayoutDashboard, 
  Receipt, 
  Package, 
  CalendarClock, 
  Users, 
  ShoppingCart, 
  BarChart3, 
  Settings,
  History
} from 'lucide-react';
import { Medicine, Page } from './types';

export const NAV_ITEMS = [
  { id: Page.DASHBOARD, label: 'Dashboard', icon: <LayoutDashboard size={18} /> },
  { id: Page.NEW_BILL, label: 'New Bill', icon: <Receipt size={18} /> },
  { id: Page.TRANSACTIONS, label: 'Transactions', icon: <History size={18} /> },
  { id: Page.INVENTORY, label: 'Inventory', icon: <Package size={18} /> },
  { id: Page.EXPIRY, label: 'Expiry Tracker', icon: <CalendarClock size={18} /> },
  { id: Page.CUSTOMERS, label: 'Customers', icon: <Users size={18} /> },
  { id: Page.PURCHASE, label: 'Purchase Entry', icon: <ShoppingCart size={18} /> },
  { id: Page.REPORTS, label: 'Reports', icon: <BarChart3 size={18} /> },
  { id: Page.SETTINGS, label: 'Settings', icon: <Settings size={18} /> },
];

export const MOCK_MEDICINES: Medicine[] = [
  { id: '1', name: 'Paracetamol 500mg', brand: 'GSK', stock: 450, batch: 'B123', expiry: '2025-06-30', buyPrice: 12.5, mrp: 20, tabletsPerStrip: 10, row: 'A1' },
  { id: '2', name: 'Amoxicillin 250mg', brand: 'Abbott', stock: 12, batch: 'AMX09', expiry: '2024-04-15', buyPrice: 45, mrp: 65, tabletsPerStrip: 10, row: 'B2' },
  { id: '3', name: 'Cetirizine 10mg', brand: 'Cipla', stock: 200, batch: 'CET44', expiry: '2025-12-01', buyPrice: 8, mrp: 15, tabletsPerStrip: 15, row: 'C1' },
  { id: '4', name: 'Metformin 500mg', brand: 'Sun Pharma', stock: 85, batch: 'MET90', expiry: '2024-03-20', buyPrice: 18, mrp: 32, tabletsPerStrip: 10, row: 'A4' },
  { id: '5', name: 'Atorvastatin 20mg', brand: 'Pfizer', stock: 310, batch: 'ATO22', expiry: '2026-01-10', buyPrice: 110, mrp: 160, tabletsPerStrip: 10, row: 'D5' },
];
