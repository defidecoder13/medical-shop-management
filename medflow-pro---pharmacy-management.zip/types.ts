
export interface Medicine {
  id: string;
  name: string;
  brand: string;
  stock: number;
  batch: string;
  expiry: string;
  buyPrice: number;
  mrp: number;
  tabletsPerStrip: number;
  row: string;
}

export interface BillItem extends Medicine {
  quantity: number;
  total: number;
}

export interface Bill {
  id: string;
  customerName: string;
  date: string;
  items: BillItem[];
  subtotal: number;
  discount: number;
  tax: number;
  grandTotal: number;
}

export enum Page {
  DASHBOARD = 'dashboard',
  NEW_BILL = 'new-bill',
  INVENTORY = 'inventory',
  EXPIRY = 'expiry',
  CUSTOMERS = 'customers',
  PURCHASE = 'purchase',
  REPORTS = 'reports',
  SETTINGS = 'settings',
  TRANSACTIONS = 'transactions'
}
