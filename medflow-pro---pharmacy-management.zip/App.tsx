
import React, { useState, useEffect } from 'react';
import { Page } from './types';
import Sidebar from './components/Sidebar';
import Topbar from './components/Topbar';
import Dashboard from './pages/Dashboard';
import NewBill from './pages/NewBill';
import Inventory from './pages/Inventory';
import ExpiryTracker from './pages/ExpiryTracker';
import Reports from './pages/Reports';
import Customers from './pages/Customers';
import PurchaseEntry from './pages/PurchaseEntry';
import Transactions from './pages/Transactions';

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<Page>(Page.DASHBOARD);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);

  // Global Keyboard Shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.altKey) {
        switch (e.key.toLowerCase()) {
          case 'd': setCurrentPage(Page.DASHBOARD); break;
          case 'n': setCurrentPage(Page.NEW_BILL); break;
          case 't': setCurrentPage(Page.TRANSACTIONS); break;
          case 'i': setCurrentPage(Page.INVENTORY); break;
          case 'e': setCurrentPage(Page.EXPIRY); break;
          case 'r': setCurrentPage(Page.REPORTS); break;
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const renderPage = () => {
    switch (currentPage) {
      case Page.DASHBOARD: return <Dashboard />;
      case Page.NEW_BILL: return <NewBill />;
      case Page.TRANSACTIONS: return <Transactions />;
      case Page.INVENTORY: return <Inventory />;
      case Page.EXPIRY: return <ExpiryTracker />;
      case Page.REPORTS: return <Reports />;
      case Page.CUSTOMERS: return <Customers />;
      case Page.PURCHASE: return <PurchaseEntry />;
      default: return <Dashboard />;
    }
  };

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden text-slate-900">
      <Sidebar 
        activePage={currentPage} 
        onPageChange={setCurrentPage} 
        collapsed={isSidebarCollapsed}
        toggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
      />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Topbar activePage={currentPage} />
        
        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-7xl mx-auto h-full">
            {renderPage()}
          </div>
        </main>
      </div>
    </div>
  );
};

export default App;
