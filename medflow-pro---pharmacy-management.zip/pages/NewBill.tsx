
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Search, Plus, Trash2, Printer, CheckCircle2, X } from 'lucide-react';
import { MOCK_MEDICINES } from '../constants';
import { Medicine, BillItem } from '../types';

const NewBill: React.FC = () => {
  const [query, setQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Medicine[]>([]);
  const [selectedItems, setSelectedItems] = useState<BillItem[]>([]);
  const [customerName, setCustomerName] = useState('Walk-in Customer');
  const [discount, setDiscount] = useState(0);
  const [tax, setTax] = useState(12); // 12% GST default
  const [showSuccess, setShowSuccess] = useState(false);

  const searchRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (searchRef.current) searchRef.current.focus();
  }, []);

  useEffect(() => {
    if (query.trim().length > 1) {
      const results = MOCK_MEDICINES.filter(m => 
        m.name.toLowerCase().includes(query.toLowerCase()) || 
        m.brand.toLowerCase().includes(query.toLowerCase())
      );
      setSearchResults(results);
    } else {
      setSearchResults([]);
    }
  }, [query]);

  const addItem = (medicine: Medicine) => {
    const existing = selectedItems.find(item => item.id === medicine.id);
    if (existing) {
      updateQuantity(medicine.id, existing.quantity + 1);
    } else {
      setSelectedItems([
        ...selectedItems,
        { ...medicine, quantity: 1, total: medicine.mrp }
      ]);
    }
    setQuery('');
    setSearchResults([]);
    searchRef.current?.focus();
  };

  const updateQuantity = (id: string, qty: number) => {
    if (qty < 1) return;
    setSelectedItems(selectedItems.map(item => 
      item.id === id ? { ...item, quantity: qty, total: qty * item.mrp } : item
    ));
  };

  const removeItem = (id: string) => {
    setSelectedItems(selectedItems.filter(item => item.id !== id));
  };

  const subtotal = selectedItems.reduce((acc, item) => acc + item.total, 0);
  const taxAmount = (subtotal * tax) / 100;
  const grandTotal = subtotal + taxAmount - discount;

  const handleGenerateBill = () => {
    if (selectedItems.length === 0) return;
    setShowSuccess(true);
    setTimeout(() => {
      setShowSuccess(false);
      setSelectedItems([]);
      setCustomerName('Walk-in Customer');
      setDiscount(0);
    }, 3000);
  };

  return (
    <div className="flex flex-col h-full gap-6 relative">
      {showSuccess && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-white/60 backdrop-blur-sm transition-all animate-in fade-in zoom-in duration-300">
          <div className="bg-white p-12 rounded-2xl shadow-2xl border border-emerald-100 flex flex-col items-center gap-4 text-center">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center">
              <CheckCircle2 size={40} />
            </div>
            <h2 className="text-2xl font-bold text-slate-800">Bill Generated Successfully</h2>
            <p className="text-slate-500">Printing receipt...</p>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 flex-1 h-full min-h-0">
        {/* Left Section: Search & Items */}
        <div className="lg:col-span-2 flex flex-col gap-6 h-full min-h-0">
          {/* Search Medicine */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm relative z-30">
            <div className="relative">
              <Search className="absolute left-3 top-3.5 text-slate-400" size={20} />
              <input
                ref={searchRef}
                type="text"
                className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-lg text-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all font-medium"
                placeholder="Start typing medicine name..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
              />
            </div>
            
            {/* Results Dropdown */}
            {searchResults.length > 0 && (
              <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-slate-200 rounded-lg shadow-xl max-h-80 overflow-y-auto z-40">
                {searchResults.map((med) => (
                  <button
                    key={med.id}
                    className="w-full text-left p-3 hover:bg-slate-50 border-b border-slate-100 flex items-center justify-between group"
                    onClick={() => addItem(med)}
                  >
                    <div>
                      <p className="font-semibold text-slate-900">{med.name}</p>
                      <p className="text-xs text-slate-500">{med.brand} • Batch: {med.batch} • Exp: {med.expiry}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-indigo-600">₹{med.mrp}</p>
                      <p className="text-[10px] uppercase font-bold text-slate-400 group-hover:text-indigo-500">Stock: {med.stock}</p>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Added Medicines Table */}
          <div className="bg-white flex-1 rounded-xl border border-slate-200 shadow-sm overflow-hidden flex flex-col min-h-0">
            <div className="p-4 border-b border-slate-100 flex justify-between items-center">
              <h3 className="font-semibold text-slate-800">Current Items ({selectedItems.length})</h3>
              <button 
                onClick={() => setSelectedItems([])}
                className="text-xs text-rose-600 font-bold uppercase hover:bg-rose-50 px-2 py-1 rounded transition-colors"
              >
                Clear All
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto">
              <table className="w-full text-left">
                <thead className="bg-slate-50 sticky top-0 border-b border-slate-200 text-[10px] font-bold uppercase tracking-wider text-slate-500">
                  <tr>
                    <th className="px-4 py-3">Medicine</th>
                    <th className="px-4 py-3">Batch/Exp</th>
                    <th className="px-4 py-3 text-center">Qty</th>
                    <th className="px-4 py-3 text-right">MRP</th>
                    <th className="px-4 py-3 text-right">Total</th>
                    <th className="px-4 py-3"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {selectedItems.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-20 text-center text-slate-400 italic">
                        No medicines added. Search above to begin.
                      </td>
                    </tr>
                  ) : (
                    selectedItems.map((item) => (
                      <tr key={item.id} className="hover:bg-slate-50 group">
                        <td className="px-4 py-3">
                          <p className="text-sm font-semibold">{item.name}</p>
                          <p className="text-xs text-slate-500">{item.brand}</p>
                        </td>
                        <td className="px-4 py-3 text-xs text-slate-500">
                          {item.batch} / {item.expiry}
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex items-center justify-center gap-2">
                            <button 
                              onClick={() => updateQuantity(item.id, item.quantity - 1)}
                              className="w-6 h-6 rounded border border-slate-300 flex items-center justify-center text-slate-500 hover:bg-slate-100"
                            >-</button>
                            <input 
                              type="number" 
                              value={item.quantity} 
                              onChange={(e) => updateQuantity(item.id, parseInt(e.target.value) || 1)}
                              className="w-12 text-center text-sm font-semibold focus:outline-none"
                            />
                            <button 
                              onClick={() => updateQuantity(item.id, item.quantity + 1)}
                              className="w-6 h-6 rounded border border-slate-300 flex items-center justify-center text-slate-500 hover:bg-slate-100"
                            >+</button>
                          </div>
                        </td>
                        <td className="px-4 py-3 text-sm text-right font-medium">₹{item.mrp.toFixed(2)}</td>
                        <td className="px-4 py-3 text-sm text-right font-bold text-slate-900">₹{item.total.toFixed(2)}</td>
                        <td className="px-4 py-3 text-right">
                          <button 
                            onClick={() => removeItem(item.id)}
                            className="p-1.5 text-slate-300 hover:text-rose-600 transition-colors"
                          >
                            <Trash2 size={16} />
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Right Section: Summary */}
        <div className="flex flex-col gap-6">
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm space-y-6 sticky top-0">
            <h3 className="font-bold text-lg text-slate-800 border-b border-slate-100 pb-4">Bill Summary</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Customer Name</label>
                <input 
                  type="text" 
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Discount (₹)</label>
                  <input 
                    type="number" 
                    value={discount}
                    onChange={(e) => setDiscount(Number(e.target.value))}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">GST (%)</label>
                  <select 
                    value={tax}
                    onChange={(e) => setTax(Number(e.target.value))}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                  >
                    <option value={0}>0%</option>
                    <option value={5}>5%</option>
                    <option value={12}>12%</option>
                    <option value={18}>18%</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="space-y-2 pt-4 border-t border-slate-100">
              <div className="flex justify-between text-sm text-slate-600 font-medium">
                <span>Subtotal</span>
                <span>₹{subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm text-slate-600 font-medium">
                <span>GST ({tax}%)</span>
                <span>+₹{taxAmount.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm text-rose-600 font-medium">
                <span>Discount</span>
                <span>-₹{discount.toFixed(2)}</span>
              </div>
              <div className="flex justify-between pt-4 text-2xl font-black text-slate-900">
                <span>Total</span>
                <span className="text-indigo-700">₹{grandTotal.toFixed(2)}</span>
              </div>
            </div>

            <div className="space-y-3 pt-6">
              <button 
                onClick={handleGenerateBill}
                disabled={selectedItems.length === 0}
                className="w-full flex items-center justify-center gap-2 bg-indigo-600 text-white py-4 rounded-xl font-bold text-lg hover:bg-indigo-700 active:scale-[0.98] transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Printer size={20} />
                Generate Bill (F10)
              </button>
              <div className="flex gap-2">
                <button className="flex-1 border border-slate-200 py-3 rounded-lg text-sm font-semibold hover:bg-slate-50">Draft</button>
                <button className="flex-1 border border-slate-200 py-3 rounded-lg text-sm font-semibold hover:bg-slate-50 text-rose-600">Cancel</button>
              </div>
            </div>
          </div>
          
          <div className="bg-indigo-900 p-4 rounded-xl text-indigo-100 text-xs">
            <h5 className="font-bold text-white mb-2 uppercase tracking-widest">Shortcuts</h5>
            <div className="grid grid-cols-2 gap-y-2">
              <p><span className="font-mono bg-indigo-800 px-1 rounded">Alt+S</span> Search</p>
              <p><span className="font-mono bg-indigo-800 px-1 rounded">F10</span> Pay</p>
              <p><span className="font-mono bg-indigo-800 px-1 rounded">Esc</span> Clear</p>
              <p><span className="font-mono bg-indigo-800 px-1 rounded">Alt+C</span> Customr</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NewBill;
