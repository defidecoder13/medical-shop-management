
import React, { useState } from 'react';
import { Download, FileSpreadsheet, Calendar, ChevronDown, CheckCircle2 } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

const data = [
  { name: 'Antibiotics', value: 45000 },
  { name: 'Pain Relief', value: 32000 },
  { name: 'Diabetic', value: 28000 },
  { name: 'Vitamins', value: 18000 },
  { name: 'Cardiac', value: 38000 },
  { name: 'Others', value: 15000 },
];

const COLORS = ['#4f46e5', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#64748b'];

const Reports: React.FC = () => {
  const [isExporting, setIsExporting] = useState(false);
  const [showToast, setShowToast] = useState(false);

  const handleExport = () => {
    setIsExporting(true);
    setTimeout(() => {
      setIsExporting(false);
      setShowToast(true);
      setTimeout(() => setShowToast(false), 3000);
    }, 1500);
  };

  return (
    <div className="space-y-6 relative">
      {showToast && (
        <div className="fixed bottom-6 right-6 bg-slate-900 text-white px-6 py-4 rounded-2xl shadow-2xl flex items-center gap-3 animate-in slide-in-from-bottom-5 duration-300 z-50">
          <CheckCircle2 className="text-emerald-400" size={20} />
          <div>
            <p className="text-sm font-bold">Report Exported!</p>
            <p className="text-xs text-slate-400">Monthly sales data is ready in your downloads.</p>
          </div>
        </div>
      )}

      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Financial Reports</h2>
          <p className="text-sm text-slate-500">Detailed insights into your sales and profit.</p>
        </div>
        <div className="flex gap-2">
          <button 
            onClick={handleExport}
            disabled={isExporting}
            className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 rounded-lg text-sm font-semibold hover:bg-slate-50 shadow-sm transition-all disabled:opacity-50"
          >
            <FileSpreadsheet size={18} className="text-emerald-600" />
            {isExporting ? 'Exporting...' : 'Export Excel'}
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm font-semibold hover:bg-indigo-700 shadow-md transition-all">
            <Download size={18} />
            Download PDF
          </button>
        </div>
      </div>

      <div className="flex bg-white p-4 rounded-xl border border-slate-200 shadow-sm gap-4 items-center overflow-x-auto">
        <div className="flex items-center gap-2 px-3 py-2 bg-slate-50 rounded-lg border border-slate-200 cursor-pointer hover:bg-slate-100 transition-all shrink-0">
          <Calendar size={16} className="text-slate-400" />
          <span className="text-sm font-medium whitespace-nowrap">Select Date Range: Feb 1, 2024 - Feb 28, 2024</span>
          <ChevronDown size={14} className="text-slate-400" />
        </div>
        <div className="flex gap-2 shrink-0">
          {['Daily', 'Weekly', 'Monthly', 'Yearly'].map((t) => (
            <button 
              key={t}
              className={`px-4 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-all ${
                t === 'Monthly' ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-500 hover:bg-slate-200'
              }`}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <h4 className="font-bold text-slate-800 mb-6">Sales by Category</h4>
          <div className="h-[350px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fontSize: 12, fill: '#64748b'}} />
                <YAxis axisLine={false} tickLine={false} tick={{fontSize: 12, fill: '#64748b'}} />
                <Tooltip 
                  cursor={{fill: '#f8fafc'}}
                  contentStyle={{ border: 'none', borderRadius: '8px', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                />
                <Bar dataKey="value" radius={[4, 4, 0, 0]} barSize={40}>
                  {data.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex flex-col">
          <h4 className="font-bold text-slate-800 mb-6">Summary Table</h4>
          <div className="space-y-4 flex-1">
            {[
              { label: 'Total Sales (Gross)', value: '₹4,52,000', trend: '+12%', trendUp: true },
              { label: 'Total Cost of Goods', value: '₹3,10,000', trend: '+8%', trendUp: false },
              { label: 'Net Profit', value: '₹1,42,000', trend: '+22%', trendUp: true },
              { label: 'Tax Collected', value: '₹54,240', trend: '+12%', trendUp: true },
              { label: 'Discounts Given', value: '₹12,400', trend: '-2%', trendUp: false },
            ].map((row, idx) => (
              <div key={idx} className="flex items-center justify-between p-4 bg-slate-50 rounded-xl border border-slate-100">
                <div>
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">{row.label}</p>
                  <p className="text-xl font-black text-slate-900 mt-1">{row.value}</p>
                </div>
                <span className={`px-2 py-1 rounded text-[10px] font-bold ${row.trendUp ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'}`}>
                  {row.trend}
                </span>
              </div>
            ))}
          </div>
          <button className="w-full mt-6 py-3 bg-slate-900 text-white rounded-xl font-bold hover:bg-slate-800 transition-all">
            Generate In-depth Audit Report
          </button>
        </div>
      </div>
    </div>
  );
};

export default Reports;
