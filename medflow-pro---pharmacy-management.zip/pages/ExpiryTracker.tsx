
import React, { useState } from 'react';
import { Calendar, AlertCircle, AlertTriangle, CheckCircle } from 'lucide-react';

const ExpiryTracker: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'30' | '60' | 'expired'>('30');

  const expiryData = {
    expired: [
      { name: 'Cold-X Tablet', batch: 'CX098', exp: '2024-01-10', stock: 45 },
      { name: 'Vitamin C Syrup', batch: 'VC11', exp: '2023-12-15', stock: 12 },
    ],
    '30': [
      { name: 'Metformin 500mg', batch: 'MET90', exp: '2024-03-20', stock: 85 },
      { name: 'Amoxicillin 250mg', batch: 'AMX09', exp: '2024-04-15', stock: 12 },
    ],
    '60': [
      { name: 'Paracetamol 650mg', batch: 'P650', exp: '2024-05-10', stock: 200 },
      { name: 'Lisinopril 10mg', batch: 'LIS-9', exp: '2024-05-22', stock: 40 },
    ]
  };

  const currentList = expiryData[activeTab];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Expiry Tracker</h2>
          <p className="text-sm text-slate-500">Proactively manage stock about to expire.</p>
        </div>
        <div className="flex bg-slate-200/50 p-1 rounded-lg">
          <button 
            onClick={() => setActiveTab('expired')}
            className={`px-4 py-1.5 rounded-md text-sm font-semibold transition-all ${activeTab === 'expired' ? 'bg-rose-500 text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}
          >
            Expired
          </button>
          <button 
            onClick={() => setActiveTab('30')}
            className={`px-4 py-1.5 rounded-md text-sm font-semibold transition-all ${activeTab === '30' ? 'bg-amber-500 text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}
          >
            Within 30 Days
          </button>
          <button 
            onClick={() => setActiveTab('60')}
            className={`px-4 py-1.5 rounded-md text-sm font-semibold transition-all ${activeTab === '60' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}
          >
            Within 60 Days
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-rose-50 border border-rose-100 p-4 rounded-xl flex items-center gap-4">
          <div className="w-12 h-12 bg-rose-100 text-rose-600 rounded-full flex items-center justify-center shrink-0">
            <AlertCircle size={24} />
          </div>
          <div>
            <p className="text-xs font-bold text-rose-500 uppercase tracking-wider">Already Expired</p>
            <p className="text-2xl font-black text-rose-900">{expiryData.expired.length} Items</p>
          </div>
        </div>
        <div className="bg-amber-50 border border-amber-100 p-4 rounded-xl flex items-center gap-4">
          <div className="w-12 h-12 bg-amber-100 text-amber-600 rounded-full flex items-center justify-center shrink-0">
            <AlertTriangle size={24} />
          </div>
          <div>
            <p className="text-xs font-bold text-amber-500 uppercase tracking-wider">Under 30 Days</p>
            <p className="text-2xl font-black text-amber-900">{expiryData['30'].length} Items</p>
          </div>
        </div>
        <div className="bg-indigo-50 border border-indigo-100 p-4 rounded-xl flex items-center gap-4">
          <div className="w-12 h-12 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center shrink-0">
            <Calendar size={24} />
          </div>
          <div>
            <p className="text-xs font-bold text-indigo-500 uppercase tracking-wider">Under 60 Days</p>
            <p className="text-2xl font-black text-indigo-900">{expiryData['60'].length} Items</p>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-slate-50 border-b border-slate-200">
            <tr>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Medicine Name</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Batch</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Expiry Date</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider text-center">Remaining Stock</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {currentList.length === 0 ? (
              <tr>
                <td colSpan={5} className="px-6 py-12 text-center text-slate-400 italic">
                  No medicines found for this category.
                </td>
              </tr>
            ) : (
              currentList.map((item, idx) => (
                <tr key={idx} className="hover:bg-slate-50 transition-colors">
                  <td className="px-6 py-4 font-semibold text-slate-900 text-sm">{item.name}</td>
                  <td className="px-6 py-4 text-sm font-mono text-slate-500">{item.batch}</td>
                  <td className="px-6 py-4 text-sm">
                    <div className="flex items-center gap-2">
                      <span className={`w-2 h-2 rounded-full ${activeTab === 'expired' ? 'bg-rose-500' : activeTab === '30' ? 'bg-amber-500' : 'bg-indigo-500'}`}></span>
                      <span className="font-medium">{item.exp}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm font-bold text-center text-slate-900">{item.stock} Units</td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button className="text-xs bg-slate-900 text-white px-3 py-1.5 rounded-md hover:bg-slate-800 font-medium">Return to Distributor</button>
                      <button className="text-xs border border-slate-200 text-slate-600 px-3 py-1.5 rounded-md hover:bg-slate-50 font-medium">Write Off</button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ExpiryTracker;
