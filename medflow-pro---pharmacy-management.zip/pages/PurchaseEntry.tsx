
import React, { useState } from 'react';
import { Plus, Search, Trash2, Save, FileText } from 'lucide-react';

const PurchaseEntry: React.FC = () => {
  return (
    <div className="space-y-6 h-full flex flex-col">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Purchase Entry (GRN)</h2>
          <p className="text-sm text-slate-500">Record incoming stock from your distributors.</p>
        </div>
        <div className="flex gap-2">
          <button className="px-4 py-2 border border-slate-200 rounded-lg text-sm font-semibold hover:bg-slate-50">Save as Draft</button>
          <button className="px-6 py-2 bg-indigo-600 text-white rounded-lg text-sm font-bold flex items-center gap-2 hover:bg-indigo-700 shadow-md">
            <Save size={18} /> Complete Entry
          </button>
        </div>
      </div>

      {/* Invoice Details */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm grid grid-cols-1 md:grid-cols-4 gap-6">
        <div>
          <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Distributor</label>
          <select className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
            <option>Select Distributor</option>
            <option>Standard Pharma Dist.</option>
            <option>Modern Medical Agencies</option>
            <option>Universal Healthcare</option>
          </select>
        </div>
        <div>
          <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Invoice Number</label>
          <input type="text" placeholder="INV-2024-001" className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
        </div>
        <div>
          <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Invoice Date</label>
          <input type="date" className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
        </div>
        <div>
          <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Tax Scheme</label>
          <select className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
            <option>GST 12% (Standard)</option>
            <option>GST 18%</option>
            <option>GST 5%</option>
            <option>Exempted</option>
          </select>
        </div>
      </div>

      {/* Items Entry Table */}
      <div className="bg-white flex-1 rounded-xl border border-slate-200 shadow-sm overflow-hidden flex flex-col min-h-0">
        <div className="flex-1 overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 border-b border-slate-200 sticky top-0">
              <tr>
                <th className="px-4 py-3 text-[10px] font-bold text-slate-500 uppercase">Medicine</th>
                <th className="px-4 py-3 text-[10px] font-bold text-slate-500 uppercase">Batch</th>
                <th className="px-4 py-3 text-[10px] font-bold text-slate-500 uppercase text-center">Qty (Strips)</th>
                <th className="px-4 py-3 text-[10px] font-bold text-slate-500 uppercase text-right">Buy Price</th>
                <th className="px-4 py-3 text-[10px] font-bold text-slate-500 uppercase text-right">MRP</th>
                <th className="px-4 py-3 text-[10px] font-bold text-slate-500 uppercase">Expiry</th>
                <th className="px-4 py-3"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {[1, 2, 3].map((i) => (
                <tr key={i} className="group">
                  <td className="px-4 py-2">
                    <div className="relative">
                      <Search size={14} className="absolute left-3 top-3 text-slate-400" />
                      <input type="text" placeholder="Search med..." className="w-full pl-8 pr-3 py-2 bg-transparent border-transparent border focus:border-indigo-200 rounded text-sm outline-none" />
                    </div>
                  </td>
                  <td className="px-4 py-2">
                    <input type="text" className="w-full px-2 py-2 bg-transparent border border-transparent focus:border-indigo-200 rounded text-sm outline-none font-mono" placeholder="BATCH-00" />
                  </td>
                  <td className="px-4 py-2 text-center">
                    <input type="number" className="w-20 px-2 py-2 bg-transparent border border-transparent focus:border-indigo-200 rounded text-sm text-center outline-none" placeholder="0" />
                  </td>
                  <td className="px-4 py-2 text-right">
                    <input type="number" className="w-24 px-2 py-2 bg-transparent border border-transparent focus:border-indigo-200 rounded text-sm text-right outline-none" placeholder="0.00" />
                  </td>
                  <td className="px-4 py-2 text-right">
                    <input type="number" className="w-24 px-2 py-2 bg-transparent border border-transparent focus:border-indigo-200 rounded text-sm text-right outline-none" placeholder="0.00" />
                  </td>
                  <td className="px-4 py-2">
                    <input type="month" className="w-full px-2 py-2 bg-transparent border border-transparent focus:border-indigo-200 rounded text-sm outline-none" />
                  </td>
                  <td className="px-4 py-2 text-right">
                    <button className="p-2 text-slate-300 hover:text-rose-600">
                      <Trash2 size={16} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <button className="m-4 px-4 py-2 border border-dashed border-indigo-200 text-indigo-600 rounded-lg text-xs font-bold uppercase tracking-wider hover:bg-indigo-50 transition-all flex items-center gap-2">
            <Plus size={14} /> Add Another Row
          </button>
        </div>

        {/* Totals Footer */}
        <div className="p-6 bg-slate-900 text-white flex justify-between items-center">
          <div className="flex gap-8">
            <div>
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Total Quantity</p>
              <p className="text-xl font-black">240 Strips</p>
            </div>
            <div>
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Gross Value</p>
              <p className="text-xl font-black">₹34,500.00</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest">Invoice Payable</p>
            <p className="text-3xl font-black text-indigo-400">₹38,640.00</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PurchaseEntry;
