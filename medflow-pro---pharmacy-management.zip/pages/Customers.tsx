
import React from 'react';
import { Users, Search, Plus, Phone, ShoppingBag } from 'lucide-react';

const Customers: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Customer Directory</h2>
          <p className="text-sm text-slate-500">Manage your patient database and purchase history.</p>
        </div>
        <button className="bg-indigo-600 text-white px-4 py-2.5 rounded-lg font-semibold text-sm flex items-center gap-2 hover:bg-indigo-700 shadow-md">
          <Plus size={18} /> Add New Customer
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {[
          { name: 'Suresh Kumar', phone: '+91 9876543210', visits: 12, spent: '₹14,500', last: '2 days ago' },
          { name: 'Priya Verma', phone: '+91 8887776665', visits: 4, spent: '₹3,200', last: '1 week ago' },
          { name: 'Amit Singh', phone: '+91 9990001112', visits: 22, spent: '₹42,800', last: 'Today' },
          { name: 'Anjali Sharma', phone: '+91 7776665554', visits: 1, spent: '₹650', last: 'Yesterday' },
        ].map((customer, idx) => (
          <div key={idx} className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow group cursor-pointer">
            <div className="flex justify-between items-start mb-4">
              <div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center text-slate-400 group-hover:bg-indigo-100 group-hover:text-indigo-600 transition-colors">
                <Users size={24} />
              </div>
              <span className="text-[10px] font-bold uppercase text-slate-400">Regular Customer</span>
            </div>
            <h4 className="font-bold text-slate-900 text-lg">{customer.name}</h4>
            <p className="flex items-center gap-2 text-sm text-slate-500 mt-1">
              <Phone size={14} /> {customer.phone}
            </p>
            <div className="grid grid-cols-2 gap-4 mt-6 pt-6 border-t border-slate-100">
              <div>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Total Spent</p>
                <p className="font-black text-slate-900">{customer.spent}</p>
              </div>
              <div>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Total Visits</p>
                <p className="font-black text-slate-900">{customer.visits}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Customers;
