
import React, { useState } from 'react';
import { 
  FileSpreadsheet, 
  Search, 
  Filter, 
  Calendar, 
  Eye, 
  Printer, 
  Download,
  ChevronLeft,
  ChevronRight,
  Clock,
  CheckCircle2,
  XCircle,
  Clock3
} from 'lucide-react';

const MOCK_TRANSACTIONS = [
  { id: 'BILL-0982', customer: 'Rohan Sharma', items: 4, amount: 1240, status: 'Paid', date: '2024-05-24', time: '02:30 PM', payment: 'Cash' },
  { id: 'BILL-0981', customer: 'Walk-in Customer', items: 1, amount: 450, status: 'Paid', date: '2024-05-24', time: '01:45 PM', payment: 'UPI' },
  { id: 'BILL-0980', customer: 'Suresh Kumar', items: 12, amount: 2890, status: 'Pending', date: '2024-05-24', time: '11:20 AM', payment: 'Credit' },
  { id: 'BILL-0979', customer: 'Priya Verma', items: 2, amount: 620, status: 'Paid', date: '2024-05-23', time: '06:15 PM', payment: 'Cash' },
  { id: 'BILL-0978', customer: 'Amit Singh', items: 5, amount: 1100, status: 'Cancelled', date: '2024-05-23', time: '04:10 PM', payment: 'N/A' },
  { id: 'BILL-0977', customer: 'Deepak Raj', items: 3, amount: 890, status: 'Paid', date: '2024-05-22', time: '10:05 AM', payment: 'Card' },
  { id: 'BILL-0976', customer: 'Anjali Gupta', items: 8, amount: 3450, status: 'Paid', date: '2024-05-21', time: '01:30 PM', payment: 'UPI' },
  { id: 'BILL-0975', customer: 'Walk-in Customer', items: 1, amount: 120, status: 'Paid', date: '2024-05-20', time: '09:20 PM', payment: 'Cash' },
];

const Transactions: React.FC = () => {
  const [filterRange, setFilterRange] = useState<'daily' | 'weekly' | 'monthly' | 'all'>('daily');
  const [search, setSearch] = useState('');
  const [isExporting, setIsExporting] = useState(false);

  const handleExportExcel = () => {
    setIsExporting(true);
    // Simulate export
    setTimeout(() => {
      setIsExporting(false);
      alert('Transaction report exported to Excel successfully!');
    }, 1200);
  };

  return (
    <div className="flex h-full gap-6 overflow-hidden">
      {/* Transaction Sidebar (Filters) */}
      <aside className="w-64 bg-white border border-slate-200 rounded-xl p-5 flex flex-col gap-6 shrink-0 shadow-sm overflow-y-auto">
        <div>
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4">View Period</h3>
          <div className="space-y-1">
            {[
              { id: 'daily', label: 'Today', icon: <Clock size={16} /> },
              { id: 'weekly', label: 'This Week', icon: <Calendar size={16} /> },
              { id: 'monthly', label: 'This Month', icon: <Calendar size={16} /> },
              { id: 'all', label: 'All History', icon: <Clock3 size={16} /> },
            ].map((item) => (
              <button
                key={item.id}
                onClick={() => setFilterRange(item.id as any)}
                className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                  filterRange === item.id 
                    ? 'bg-indigo-50 text-indigo-700' 
                    : 'text-slate-600 hover:bg-slate-50'
                }`}
              >
                <span className={filterRange === item.id ? 'text-indigo-600' : 'text-slate-400'}>
                  {item.icon}
                </span>
                {item.label}
              </button>
            ))}
          </div>
        </div>

        <div>
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4">Quick Stats</h3>
          <div className="space-y-3">
            <div className="p-3 bg-slate-50 border border-slate-100 rounded-lg">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Total Volume</p>
              <p className="text-lg font-black text-slate-900">₹1,45,200</p>
            </div>
            <div className="p-3 bg-slate-50 border border-slate-100 rounded-lg">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Total Bills</p>
              <p className="text-lg font-black text-slate-900">1,240</p>
            </div>
          </div>
        </div>

        <div className="mt-auto">
          <button 
            onClick={handleExportExcel}
            disabled={isExporting}
            className="w-full flex items-center justify-center gap-2 bg-emerald-600 text-white py-3 rounded-xl font-bold text-sm hover:bg-emerald-700 transition-all shadow-sm active:scale-[0.98] disabled:opacity-50"
          >
            {isExporting ? 'Exporting...' : (
              <>
                <FileSpreadsheet size={18} />
                Export to Excel
              </>
            )}
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col gap-6 min-w-0">
        {/* Actions Bar */}
        <div className="flex items-center justify-between gap-4">
          <div className="relative flex-1 max-w-lg">
            <Search className="absolute left-3 top-3 text-slate-400" size={18} />
            <input 
              type="text" 
              placeholder="Search by Bill ID or Customer Name..."
              className="w-full pl-10 pr-4 py-3 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 shadow-sm transition-all"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <div className="flex gap-2">
            <button className="flex items-center gap-2 px-4 py-3 bg-white border border-slate-200 rounded-xl text-sm font-semibold hover:bg-slate-50 shadow-sm transition-all">
              <Filter size={18} className="text-slate-400" />
              Advanced Filters
            </button>
            <button className="flex items-center gap-2 px-4 py-3 bg-indigo-600 text-white rounded-xl text-sm font-bold hover:bg-indigo-700 shadow-md transition-all">
              <Download size={18} />
              Bulk Print
            </button>
          </div>
        </div>

        {/* Transactions Table Container */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex-1 flex flex-col min-h-0">
          <div className="overflow-x-auto flex-1">
            <table className="w-full text-left border-collapse min-w-[800px]">
              <thead className="bg-slate-50 sticky top-0 border-b border-slate-200 z-10">
                <tr>
                  <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Bill ID</th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Customer</th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Items</th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Date & Time</th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">Amount</th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Payment</th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Status</th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider text-center">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {MOCK_TRANSACTIONS.filter(tx => 
                  tx.id.toLowerCase().includes(search.toLowerCase()) || 
                  tx.customer.toLowerCase().includes(search.toLowerCase())
                ).map((tx) => (
                  <tr key={tx.id} className="hover:bg-slate-50 transition-colors group">
                    <td className="px-6 py-4 font-mono text-sm font-bold text-indigo-600">{tx.id}</td>
                    <td className="px-6 py-4">
                      <p className="text-sm font-semibold text-slate-900">{tx.customer}</p>
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-600">{tx.items} items</td>
                    <td className="px-6 py-4">
                      <p className="text-sm font-medium text-slate-900">{tx.date}</p>
                      <p className="text-[10px] text-slate-400 font-bold uppercase">{tx.time}</p>
                    </td>
                    <td className="px-6 py-4 text-sm font-black text-right text-slate-900">₹{tx.amount.toLocaleString()}</td>
                    <td className="px-6 py-4">
                      <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">{tx.payment}</span>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider flex items-center gap-1.5 w-fit ${
                        tx.status === 'Paid' ? 'bg-emerald-100 text-emerald-700' :
                        tx.status === 'Pending' ? 'bg-amber-100 text-amber-700' :
                        'bg-rose-100 text-rose-700'
                      }`}>
                        {tx.status === 'Paid' && <CheckCircle2 size={12} />}
                        {tx.status === 'Pending' && <Clock3 size={12} />}
                        {tx.status === 'Cancelled' && <XCircle size={12} />}
                        {tx.status}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center justify-center gap-2">
                        <button title="View Bill" className="p-2 text-slate-400 hover:text-indigo-600 rounded-lg hover:bg-indigo-50 transition-all">
                          <Eye size={16} />
                        </button>
                        <button title="Re-print" className="p-2 text-slate-400 hover:text-indigo-600 rounded-lg hover:bg-indigo-50 transition-all">
                          <Printer size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          
          {/* Pagination */}
          <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Showing 1 to 8 of 1,240 entries</span>
            <div className="flex items-center gap-1">
              <button className="p-2 text-slate-400 hover:text-slate-900 disabled:opacity-30" disabled>
                <ChevronLeft size={18} />
              </button>
              {[1, 2, 3, '...', 12].map((p, i) => (
                <button 
                  key={i} 
                  className={`min-w-[32px] h-8 text-xs font-bold rounded-lg transition-all ${
                    p === 1 ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  {p}
                </button>
              ))}
              <button className="p-2 text-slate-400 hover:text-slate-900">
                <ChevronRight size={18} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Transactions;
