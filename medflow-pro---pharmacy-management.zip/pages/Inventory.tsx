
import React, { useState } from 'react';
import { Plus, Filter, Search, Edit3, MoreVertical, Trash2, ArrowUpDown } from 'lucide-react';
import { MOCK_MEDICINES } from '../constants';

const Inventory: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredMeds = MOCK_MEDICINES.filter(m => 
    m.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    m.brand.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6 h-full flex flex-col">
      {/* Header Actions */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Inventory Management</h2>
          <p className="text-sm text-slate-500">Manage your medicine stock and pricing.</p>
        </div>
        <button className="flex items-center gap-2 bg-indigo-600 text-white px-4 py-2.5 rounded-lg font-semibold text-sm hover:bg-indigo-700 transition-colors shadow-sm">
          <Plus size={18} />
          Add New Medicine
        </button>
      </div>

      {/* Filters Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-2.5 text-slate-400" size={18} />
          <input 
            type="text" 
            placeholder="Search by name, brand or batch..."
            className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex gap-2">
          <button className="flex items-center gap-2 px-4 py-2 border border-slate-200 rounded-lg text-sm font-medium hover:bg-slate-50">
            <Filter size={16} />
            Filter
          </button>
          <button className="flex items-center gap-2 px-4 py-2 border border-slate-200 rounded-lg text-sm font-medium hover:bg-slate-50">
            <ArrowUpDown size={16} />
            Sort
          </button>
        </div>
      </div>

      {/* Data Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden flex-1 flex flex-col min-h-0">
        <div className="flex-1 overflow-x-auto overflow-y-auto">
          <table className="w-full text-left border-collapse">
            <thead className="bg-slate-50 sticky top-0 border-b border-slate-200 z-10">
              <tr>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Medicine Name</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Brand</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Stock</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Batch</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Expiry</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">MRP</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Location</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredMeds.map((med) => (
                <tr key={med.id} className="hover:bg-slate-50 transition-colors group">
                  <td className="px-6 py-4 font-semibold text-slate-900 text-sm">{med.name}</td>
                  <td className="px-6 py-4 text-slate-600 text-sm">{med.brand}</td>
                  <td className="px-6 py-4 text-sm">
                    <span className={`font-bold ${med.stock < 50 ? 'text-rose-600' : 'text-slate-900'}`}>
                      {med.stock}
                    </span>
                    <span className="text-[10px] text-slate-400 ml-1">UNITS</span>
                  </td>
                  <td className="px-6 py-4 text-xs font-mono text-slate-500">{med.batch}</td>
                  <td className="px-6 py-4 text-sm">
                    <span className={new Date(med.expiry) < new Date('2024-12-31') ? 'text-amber-600 font-medium' : 'text-slate-600'}>
                      {med.expiry}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm font-semibold text-right">₹{med.mrp.toFixed(2)}</td>
                  <td className="px-6 py-4">
                    <span className="bg-slate-100 text-slate-600 px-2 py-0.5 rounded text-[10px] font-bold">ROW: {med.row}</span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center justify-center gap-1">
                      <button className="p-1.5 text-slate-400 hover:text-indigo-600 rounded hover:bg-indigo-50 transition-all">
                        <Edit3 size={16} />
                      </button>
                      <button className="p-1.5 text-slate-400 hover:text-rose-600 rounded hover:bg-rose-50 transition-all">
                        <Trash2 size={16} />
                      </button>
                      <button className="p-1.5 text-slate-400 hover:text-slate-600 rounded hover:bg-slate-100 transition-all">
                        <MoreVertical size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs font-medium text-slate-500">
          <p>Showing {filteredMeds.length} of {MOCK_MEDICINES.length} medicines</p>
          <div className="flex gap-2">
            <button className="px-3 py-1 bg-white border border-slate-200 rounded shadow-sm disabled:opacity-50" disabled>Previous</button>
            <button className="px-3 py-1 bg-indigo-600 text-white border border-indigo-700 rounded shadow-sm">1</button>
            <button className="px-3 py-1 bg-white border border-slate-200 rounded shadow-sm">2</button>
            <button className="px-3 py-1 bg-white border border-slate-200 rounded shadow-sm">Next</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Inventory;
