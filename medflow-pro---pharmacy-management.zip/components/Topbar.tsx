
import React from 'react';
import { Search, Bell, AlertTriangle, UserCircle } from 'lucide-react';
import { Page } from '../types';

interface TopbarProps {
  activePage: Page;
}

const Topbar: React.FC<TopbarProps> = ({ activePage }) => {
  return (
    <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-6 shrink-0 z-10">
      <div className="flex items-center gap-8 flex-1">
        <h1 className="text-lg font-semibold text-slate-800 capitalize">
          {activePage.replace('-', ' ')}
        </h1>

        {/* Global Medicine Search */}
        <div className="relative max-w-md w-full hidden md:block">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
            <Search size={16} />
          </div>
          <input
            type="text"
            className="block w-full pl-10 pr-3 py-2 border border-slate-200 rounded-lg bg-slate-50 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all"
            placeholder="Search medicine (Ctrl + K)"
          />
        </div>
      </div>

      <div className="flex items-center gap-4">
        {/* Sales Stats (Quick View) */}
        <div className="hidden lg:flex items-center gap-6 px-6 py-1 border-r border-slate-200 mr-2">
          <div className="text-right">
            <p className="text-[10px] uppercase tracking-wider text-slate-400 font-bold">Today's Sales</p>
            <p className="text-sm font-semibold">₹14,582</p>
          </div>
          <div className="text-right">
            <p className="text-[10px] uppercase tracking-wider text-slate-400 font-bold">Bills</p>
            <p className="text-sm font-semibold">42</p>
          </div>
        </div>

        {/* Notifications */}
        <div className="flex items-center gap-2">
          <button className="p-2 text-amber-500 bg-amber-50 rounded-full hover:bg-amber-100 transition-colors relative" title="Low Stock Alert">
            <AlertTriangle size={18} />
            <span className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
          </button>
          <button className="p-2 text-slate-500 hover:bg-slate-100 rounded-full transition-colors">
            <Bell size={18} />
          </button>
        </div>

        {/* User Profile */}
        <button className="flex items-center gap-2 pl-2 border-l border-slate-200 ml-2">
          <div className="text-right hidden sm:block">
            <p className="text-xs font-semibold">RK Pharmacy</p>
            <p className="text-[10px] text-slate-400">Store Admin</p>
          </div>
          <UserCircle size={32} className="text-slate-300" />
        </button>
      </div>
    </header>
  );
};

export default Topbar;
