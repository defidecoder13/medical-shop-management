
import React from 'react';
import { ChevronLeft, ChevronRight, LogOut } from 'lucide-react';
import { NAV_ITEMS } from '../constants';
import { Page } from '../types';

interface SidebarProps {
  activePage: Page;
  onPageChange: (page: Page) => void;
  collapsed: boolean;
  toggleCollapse: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activePage, onPageChange, collapsed, toggleCollapse }) => {
  return (
    <aside className={`${collapsed ? 'w-16' : 'w-64'} transition-all duration-300 bg-white border-r border-slate-200 flex flex-col z-20`}>
      {/* App Branding */}
      <div className="h-16 flex items-center px-4 border-b border-slate-100 shrink-0 overflow-hidden">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center shrink-0">
            <span className="text-white font-bold text-xl leading-none">+</span>
          </div>
          {!collapsed && (
            <span className="font-bold text-lg tracking-tight whitespace-nowrap">MedFlow Pro</span>
          )}
        </div>
      </div>

      {/* Navigation Links */}
      <nav className="flex-1 overflow-y-auto py-4 px-2 space-y-1">
        {NAV_ITEMS.map((item) => (
          <button
            key={item.id}
            onClick={() => onPageChange(item.id as Page)}
            className={`
              w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors
              ${activePage === item.id 
                ? 'bg-indigo-50 text-indigo-700 shadow-sm' 
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }
            `}
            title={collapsed ? item.label : undefined}
          >
            <span className={`${activePage === item.id ? 'text-indigo-600' : 'text-slate-400'}`}>
              {item.icon}
            </span>
            {!collapsed && <span className="flex-1 text-left">{item.label}</span>}
          </button>
        ))}
      </nav>

      {/* Footer Actions */}
      <div className="p-2 border-t border-slate-100">
        <button
          onClick={toggleCollapse}
          className="w-full flex items-center gap-3 px-3 py-2 text-slate-500 hover:bg-slate-100 rounded-lg text-sm transition-colors"
        >
          {collapsed ? <ChevronRight size={18} /> : <ChevronLeft size={18} />}
          {!collapsed && <span>Collapse Sidebar</span>}
        </button>
        <button className="w-full flex items-center gap-3 px-3 py-2 text-red-500 hover:bg-red-50 rounded-lg text-sm transition-colors">
          <LogOut size={18} />
          {!collapsed && <span>Logout</span>}
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;
